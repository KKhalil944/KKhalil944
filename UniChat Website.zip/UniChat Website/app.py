import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE_DIR, 'unichat.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Models
class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text, nullable=False)
    author = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    answers = db.relationship('Answer', backref='question', cascade='all, delete-orphan', lazy=True)

class Answer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.Text, nullable=False)
    author = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    question_id = db.Column(db.Integer, db.ForeignKey('question.id'), nullable=False)

# Routes
@app.route('/')
def index():
    q = request.args.get('q', '').strip()
    if q:
        # simple search on title or body
        questions = Question.query.filter(
            (Question.title.contains(q)) | (Question.body.contains(q))
        ).order_by(Question.created_at.desc()).all()
    else:
        questions = Question.query.order_by(Question.created_at.desc()).all()
    return render_template('index.html', questions=questions, q=q)

@app.route('/ask', methods=('GET', 'POST'))
def ask():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        body = request.form.get('body', '').strip()
        author = request.form.get('author', '').strip() or 'Anonymous'
        if not title or not body:
            error = 'Please provide both a title and details.'
            return render_template('ask.html', error=error, title=title, body=body, author=author)
        question = Question(title=title, body=body, author=author)
        db.session.add(question)
        db.session.commit()
        return redirect(url_for('question_view', question_id=question.id))
    return render_template('ask.html')

@app.route('/question/<int:question_id>', methods=('GET', 'POST'))
def question_view(question_id):
    question = Question.query.get_or_404(question_id)
    if request.method == 'POST':
        body = request.form.get('body', '').strip()
        author = request.form.get('author', '').strip() or 'Anonymous'
        if body:
            answer = Answer(body=body, author=author, question=question)
            db.session.add(answer)
            db.session.commit()
            return redirect(url_for('question_view', question_id=question_id))
    return render_template('question.html', question=question)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()

    app.run(debug=True)
